# FitLive - Treino Personalizado com Videoconferência

Bem-vindo ao **FitLive**, um aplicativo móvel inovador que integra videoconferência Jitsi Meet com ferramentas de acompanhamento de exercícios em tempo real. O app foi desenvolvido com React Native, Expo e TypeScript, oferecendo uma experiência fluida e intuitiva para treinos personalizados.

## 🎯 Características Principais

### 1. **Videoconferência Integrada**
- Conexão ao vivo com instrutores através do Jitsi Meet
- Controles de câmera e microfone
- Suporte para múltiplos participantes

### 2. **Cronômetro Inteligente**
- Temporizador configurável por exercício
- Controles Play/Pause/Reset
- Feedback visual de conclusão

### 3. **Contador de Repetições**
- Incremento/decremento manual
- Meta de repetições com feedback visual
- Indicador de conclusão (cor verde)

### 4. **Gerenciamento de Treinos**
- Biblioteca de treinos pré-configurados
- Três níveis de dificuldade (Iniciante, Intermediário, Avançado)
- Detalhes completos de cada exercício

### 5. **Histórico e Estatísticas**
- Rastreamento de sessões completadas
- Estatísticas de performance
- Resumo de treinos

## 📱 Estrutura de Telas

### Home Screen
- Saudação personalizada
- Card "Treino Agora" destacado
- Lista de treinos favoritos
- Estatísticas rápidas
- Pull-to-refresh

### Treinos (Workouts)
- Lista completa de treinos disponíveis
- Filtros por dificuldade
- Detalhes de cada treino

### Treino ao Vivo (Live Workout)
- Videoconferência Jitsi Meet (50% superior)
- Cronômetro com controles (25% inferior)
- Contador de repetições (25% inferior)
- Botões de navegação entre exercícios

### Conclusão de Treino
- Resumo da sessão
- Estatísticas de performance
- Opções para voltar ao home ou escolher novo treino

### Histórico
- Lista de sessões anteriores
- Detalhes de cada sessão

### Configurações
- Perfil do usuário
- Preferências de notificação
- Tema (claro/escuro)
- Informações do app

## 🚀 Como Usar

### Instalação

1. Clone o repositório:
```bash
cd /home/ubuntu/fitlive-app
```

2. Instale as dependências:
```bash
npm install
# ou
pnpm install
```

3. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

### Fluxo de Uso Básico

1. **Abra o app** → Veja a Home Screen
2. **Toque em "Treino Agora"** → Inicia uma sessão de treino
3. **Conecte-se ao Jitsi Meet** → Videoconferência com instrutor
4. **Use o cronômetro e contador** → Acompanhe cada exercício
5. **Navegue entre exercícios** → Toque "Próximo Exercício"
6. **Finalize o treino** → Veja o resumo de performance

## 🛠️ Arquitetura Técnica

### Stack Tecnológico

- **Framework**: React Native 0.81
- **Plataforma**: Expo SDK 54
- **Linguagem**: TypeScript 5.9
- **Styling**: NativeWind 4 (Tailwind CSS)
- **Roteamento**: Expo Router 6
- **Animações**: React Native Reanimated 4.x
- **Videoconferência**: Jitsi Meet + react-native-jitsi-meet

### Estrutura de Pastas

```
fitlive-app/
├── app/                          # Rotas e telas
│   ├── (tabs)/                   # Telas com tab bar
│   │   ├── index.tsx             # Home Screen
│   │   ├── workouts.tsx          # Lista de Treinos
│   │   ├── history.tsx           # Histórico
│   │   └── settings.tsx          # Configurações
│   ├── workout-detail.tsx        # Detalhes do Treino
│   ├── live-workout.tsx          # Treino ao Vivo
│   └── workout-complete.tsx      # Conclusão
├── components/                   # Componentes reutilizáveis
│   ├── timer-display.tsx         # Cronômetro
│   ├── rep-counter.tsx           # Contador de Reps
│   ├── workout-card.tsx          # Card de Treino
│   ├── jitsi-meet-view.tsx       # Integração Jitsi
│   └── screen-container.tsx      # Wrapper SafeArea
├── hooks/                        # Custom Hooks
│   ├── use-workout-state.ts      # Estado do Treino
│   ├── use-colors.ts             # Cores do Tema
│   └── use-color-scheme.ts       # Detecção de Tema
├── lib/                          # Utilitários
│   ├── types.ts                  # Tipos TypeScript
│   ├── mock-data.ts              # Dados de Teste
│   └── utils.ts                  # Funções Utilitárias
├── assets/                       # Imagens e Ícones
│   └── images/
│       ├── icon.png              # Logo do App
│       ├── splash-icon.png       # Splash Screen
│       └── favicon.png           # Favicon
├── theme.config.js               # Configuração de Cores
├── tailwind.config.js            # Configuração Tailwind
├── app.config.ts                 # Configuração Expo
└── package.json                  # Dependências
```

### Tipos de Dados Principais

```typescript
interface Workout {
  id: string;
  name: string;
  description?: string;
  instructor?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedDuration: number;
  exercises: Exercise[];
  isFavorite?: boolean;
}

interface Exercise {
  id: string;
  name: string;
  description?: string;
  duration: number;
  reps?: number;
}

interface WorkoutSession {
  id: string;
  workoutId: string;
  startTime: Date;
  endTime?: Date;
  exercises: ExerciseSession[];
  completed: boolean;
}
```

## 🎨 Design & Branding

### Paleta de Cores

| Cor | Código | Uso |
|-----|--------|-----|
| Primária | `#FF6B35` | Botões, destaques, ícones ativos |
| Secundária | `#004E89` | Backgrounds, textos secundários |
| Sucesso | `#22C55E` | Indicadores de conclusão |
| Fundo | `#FFFFFF` (light) / `#0F0F0F` (dark) | Background principal |
| Superfície | `#F5F5F5` (light) / `#1A1A1A` (dark) | Cards, superfícies |

### Logo

O logo do FitLive combina:
- **Haltere** (laranja) → Força e movimento
- **Play/Câmera** (azul) → Videoconferência
- **Linhas dinâmicas** → Energia e velocidade

## 📋 Fluxo de Dados

```
Home Screen
    ↓
Workout Detail
    ↓
Live Workout (com Jitsi Meet)
    ├── Timer (cronômetro)
    ├── Rep Counter (contador)
    └── Exercise Navigation
    ↓
Workout Complete (resumo)
    ↓
Home Screen (volta)
```

## 🔧 Configuração Avançada

### Integração Jitsi Meet

Para configurar um servidor Jitsi customizado:

```typescript
// Em components/jitsi-meet-view.tsx
const JITSI_SERVER = 'https://seu-servidor-jitsi.com';
```

Veja `JITSI_INTEGRATION.md` para instruções completas.

### Permissões (Android/iOS)

O app requer permissões para:
- **Câmera**: Videoconferência
- **Microfone**: Áudio durante treino
- **Armazenamento**: Histórico local (futuro)

## 📊 Dados Mock

O app inclui dados mock para demonstração:

- **3 Treinos** com diferentes dificuldades
- **12 Exercícios** variados
- **1 Usuário** de exemplo com histórico

Para usar dados reais, implemente a integração com backend em `lib/mock-data.ts`.

## 🧪 Testes

### Executar Testes

```bash
npm run test
```

### Testar em Dispositivo Real

1. **iOS**: `npm run ios`
2. **Android**: `npm run android`
3. **Web**: `npm run dev` (já está rodando)

## 📈 Próximas Melhorias

### Curto Prazo
- [ ] Persistência de dados com AsyncStorage
- [ ] Tratamento de erros de conexão
- [ ] Indicadores de qualidade de vídeo

### Médio Prazo
- [ ] Backend para gerenciar salas e usuários
- [ ] Suporte a múltiplos instrutores
- [ ] Gravação de sessões
- [ ] Notificações push

### Longo Prazo
- [ ] Análise de performance com IA
- [ ] Integração com wearables
- [ ] Marketplace de treinos
- [ ] Comunidade de usuários

## 📚 Documentação Adicional

- `design.md` - Especificações de design e UX
- `JITSI_INTEGRATION.md` - Guia de integração Jitsi Meet
- `todo.md` - Lista de tarefas do projeto

## 🤝 Contribuindo

Para contribuir com melhorias:

1. Crie uma branch: `git checkout -b feature/sua-feature`
2. Commit suas mudanças: `git commit -m 'Add sua-feature'`
3. Push para a branch: `git push origin feature/sua-feature`
4. Abra um Pull Request

## 📄 Licença

Este projeto é fornecido como exemplo educacional.

## 🆘 Suporte

Para problemas ou dúvidas:

1. Verifique a documentação em `JITSI_INTEGRATION.md`
2. Consulte os logs do console
3. Teste em diferentes dispositivos

## 🎓 Aprendizados

Este projeto demonstra:

- Integração de videoconferência em apps mobile
- Gerenciamento de estado complexo com hooks
- Styling com Tailwind CSS em React Native
- Roteamento avançado com Expo Router
- Componentes reutilizáveis e bem estruturados
- Boas práticas de TypeScript

---

**Desenvolvido com ❤️ usando Manus AI + Expo**

Versão: 1.0.0  
Data: Maio 2026
