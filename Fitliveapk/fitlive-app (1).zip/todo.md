# FitLive - Project TODO

## Core Features

### Navigation & Layout
- [x] Implementar navegação com tab bar (Home, Workouts, History, Settings)
- [x] Criar ScreenContainer para todas as telas
- [x] Configurar Expo Router com rotas dinâmicas

### Home Screen
- [x] Criar tela inicial com saudação personalizada
- [x] Implementar card "Treino Agora"
- [x] Adicionar lista de treinos disponíveis
- [x] Implementar pull-to-refresh
- [x] Exibir estatísticas rápidas (total de sessões, tempo)

### Workout Detail Screen
- [x] Criar tela de detalhes do treino
- [x] Exibir nome, descrição, duração, séries
- [x] Implementar botão "Iniciar Treino ao Vivo"
- [ ] Adicionar funcionalidade de favoritar treino
- [ ] Implementar compartilhamento de treino

### Live Workout Screen (Videoconferência + Controles)
- [x] Integrar Jitsi Meet SDK
- [x] Criar container de vídeo (50% superior)
- [x] Implementar painel de controle de exercícios (50% inferior)
- [x] Criar componente TimerDisplay com Play/Pause/Reset
- [x] Criar componente RepCounter com +/- buttons
- [x] Implementar exibição do exercício atual (nome e série)
- [x] Adicionar botão "Próximo Exercício"
- [x] Adicionar botão "Encerrar Treino"
- [x] Implementar manter tela ativa (expo-keep-awake)
- [x] Adicionar controles de vídeo (mute, câmera, sair)

### Jitsi Meet Integration
- [x] Configurar react-native-jitsi-meet ou alternativa
- [x] Implementar conexão com sala de videoconferência
- [ ] Gerenciar permissões de câmera e microfone (requer config nativa)
- [ ] Implementar desconexão segura (requer config nativa)

### Timer & Counter Logic
- [x] Implementar cronômetro com intervalo configurável
- [x] Implementar contador de repetições
- [ ] Sincronizar timer com intervalo de descanso
- [x] Adicionar feedback visual de conclusão (cor verde)
- [ ] Implementar notificações de transição

### Workout Completion Screen
- [x] Criar tela de resumo final
- [x] Exibir duração total, exercícios completados, total de reps
- [x] Implementar estatísticas de performance
- [x] Adicionar botão "Voltar ao Home"
- [ ] Implementar opção de salvar/compartilhar resultado

### Workout History Screen
- [x] Criar tela de histórico de treinos (placeholder)
- [ ] Implementar lista de sessões anteriores
- [ ] Adicionar filtros por período
- [ ] Exibir detalhes de cada sessão

### Settings Screen
- [x] Criar tela de configurações
- [x] Implementar perfil do usuário
- [ ] Adicionar preferências de notificação
- [x] Implementar toggle de tema (claro/escuro)
- [x] Adicionar seção "Sobre"

## Styling & Branding
- [x] Gerar logo customizado para o app
- [x] Atualizar app.config.ts com nome e branding
- [x] Configurar paleta de cores (laranja #FF6B35, azul #004E89)
- [x] Aplicar tema consistente em todas as telas
- [x] Implementar dark mode support

## Data Management
- [x] Definir estrutura de dados de treino (Exercise, Workout, Session)
- [ ] Implementar AsyncStorage para persistência local
- [x] Criar mock data para testes
- [ ] Implementar salvar histórico de sessões

## Testing & Polish
- [ ] Testar fluxo completo de treino
- [ ] Validar integração com Jitsi Meet
- [ ] Testar responsividade em diferentes tamanhos de tela
- [ ] Verificar acessibilidade (VoiceOver, contraste)
- [ ] Otimizar performance (lazy loading, renderização)
- [ ] Testar em iOS e Android

## Deployment
- [ ] Criar checkpoint final
- [ ] Gerar APK para Android
- [ ] Preparar para publicação

## Bug Fixes & Improvements
- (Nenhum item no momento)


## Integração Jitsi Meet - Fase 2

### Jitsi Web Integration
- [x] Implementar iframe do Jitsi Meet para web
- [x] Configurar eventos de conexão/desconexão
- [x] Implementar controles de áudio/vídeo
- [x] Adicionar gerenciamento de estado da conferência

### Jitsi Native Integration (Android/iOS)
- [x] Instalar e configurar react-native-jitsi-meet
- [ ] Implementar permissões de câmera e microfone
- [ ] Testar em dispositivos reais
- [ ] Adicionar tratamento de erros de conexão

### Features Avançadas
- [ ] Sincronizar cronômetro com estado da conferência
- [ ] Adicionar indicador de qualidade de vídeo
- [ ] Implementar chat integrado
- [ ] Adicionar gravação de sessões
